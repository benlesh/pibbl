import * as runtime from './runtime.mjs'; import {mount,actions,getState} from './app.js';
const canvas=document.querySelector('canvas'); const inspector=null;const app=mount(canvas);
window.applicationState=getState; window.inspectionCalls=[];

for(const [name,invoke]of Object.entries(actions)){const b=document.createElement('button');b.textContent=name;b.onclick=invoke;document.querySelector('nav').append(b);}window.addEventListener('keydown',e=>({u:actions.update,z:actions.zoom,r:actions.reset,f:actions.focus,g:actions.unfocus})[e.key]?.());
canvas.addEventListener('pointermove',()=>{document.querySelector('pre').textContent=JSON.stringify(getState(),null,2);});window.addEventListener('pagehide',()=>{inspector?.dispose();app.dispose();});
