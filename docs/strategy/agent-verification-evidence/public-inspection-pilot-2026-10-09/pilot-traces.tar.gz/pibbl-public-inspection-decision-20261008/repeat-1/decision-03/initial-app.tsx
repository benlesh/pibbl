import { Clip, Group, Overlay, Rectangle, pibbl, signal, useRef } from '@pibbl/core';
import {useOptionalInspection} from './inspection-bridge.mjs';
import { LinearScale, LineSeries, useLinearScale } from '@pibbl/core/viz';
const initial = () => [{id:'a',x:0,y:10},{id:'b',x:5,y:20},{id:'c',x:10,y:30}];
const data = signal(initial());
const domain = signal([0,10] as readonly [number,number]);
const focused = signal(false);
const hover = signal<string|null>(null);
let evaluated = initial();
function Plot() {
  const currentScale = useLinearScale('time').get();
  const mountScale = useRef(currentScale);
  const x = currentScale;
  const rows = data.get();
  const inspection=useOptionalInspection({data:rows,x:"x",y:"y"});
  evaluated = rows.map(row => ({...row}));
  const path = new Path2D(); path.rect(0, 0, focused.get() ? 299 : 600, 240);
  return <><Rectangle onPointerMove={event => { const time=x.invert(event.x-55); const candidates=focused.get() ? rows.filter(row => currentScale.map(row.x) < 299) : rows; let nearest=candidates[0]; for(const row of candidates) if(Math.abs(row.x-time)<Math.abs(nearest.x-time)) nearest=row; hover.set(nearest.id); }} onPointerLeave={() => hover.set(null)} style={{width:600,height:240,fill:'white'}} /><Clip style={{d:path}}><LineSeries inspection={inspection} data={rows} x="x" y="y" xScale="time" yScale="value" pointerEvents="none" style={{stroke:'#2563eb',strokeWidth:4}} /></Clip></>;
}
function Scene() { return <><Rectangle pointerEvents="none" style={{width:710,height:420,fill:'#f4f7fb'}} /><Group style={{translateX:55,translateY:90}}><Overlay style={{width:600,height:240}}><LinearScale id="time" domain={domain} range="width" style={{width:'100%',height:'100%'}}><LinearScale id="value" domain={[0, 40]} range="height" reverse><Plot /></LinearScale></LinearScale></Overlay></Group></>; }
export function mount(canvas: HTMLCanvasElement) { return pibbl(canvas,<Scene />,{pixelRatio:1}); }
export const actions = {
  update() { data.set(data.get().map(row => row.id === "b" ? { ...row, y: 30 } : row)); },
  zoom() { domain.set([2.5,7.5]); },
  focus() { focused.set(true); },
  unfocus() { focused.set(false); },
  reset() { focused.set(false); data.set(initial()); domain.set([0,10]); hover.set(null); },
};
export function getState() { return {source:data.get().map(row=>({...row})),evaluated:evaluated.map(row=>({...row})),domain:[...domain.get()],hover:hover.get(),focused:focused.get()}; }
