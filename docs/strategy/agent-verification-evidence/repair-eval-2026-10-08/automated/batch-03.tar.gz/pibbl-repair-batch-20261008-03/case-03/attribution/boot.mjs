import * as runtime from './runtime.mjs'; import {mount,actions,getState} from './app.js';
const canvas=document.querySelector('canvas'); const inspector=runtime.createLineAttributionInspector(canvas);const app=mount(canvas);
window.applicationState=getState; window.inspectionCalls=[];
window.inspectPlot=point=>{const result={snapshot:inspector.snapshot(),query:inspector.segmentAt(point)};window.inspectionCalls.push({at:performance.now(),point,result});return result;};
for(const [name,invoke]of Object.entries(actions)){const b=document.createElement('button');b.textContent=name;b.onclick=invoke;document.querySelector('nav').append(b);}window.addEventListener('keydown',e=>({u:actions.update,z:actions.zoom,r:actions.reset})[e.key]?.());
canvas.addEventListener('pointermove',()=>{document.querySelector('pre').textContent=JSON.stringify(getState(),null,2);});window.addEventListener('pagehide',()=>{inspector?.dispose();app.dispose();});
